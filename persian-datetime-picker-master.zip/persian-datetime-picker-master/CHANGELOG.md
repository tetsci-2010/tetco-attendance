## 3.2.0
* [FEATURE] Add holiday configuration support to Persian date picker
## 3.1.1
* [FIX] Fix incompatible with flutter 3.35.1.
## 3.1.0
* [BREAKING] Fix incompatible with flutter 3.27
## 3.0.1
* [BREAKING] Update package to version 3 to support material 3
## 2.7.0
* [FIX]  TextTheme: Updated properties to match Material Design 3 and Flutter 3.22.0 compatibility. (https://github.com/M-amir-M/persian-datetime-picker/issues/78), #78
## 2.6.0
* [FIX]  Fix the issue related to the new 3rd version of Flutter. (https://github.com/M-amir-M/persian-datetime-picker/issues/59), #59
## 2.5.1
* [FIX]  Fix responsive issues
## 2.5.0
* [FIX]  Fix flutter lint error in Flutter 3.
* [FIX]  Fix some issues.
## 2.4.0
* [FIX]  Fix WhitelistingTextInputFormatter error in Flutter 2.8.
## 2.3.0
* [BREAKING]  Now,We support (null-safety), check out the [migration guide](https://dart.dev/null-safety/migration-guide).
## 2.2.0 
* [FEATURE] Add cupertino date picker.
## 2.1.0 
* [FEATURE] Add range date picker.
## 2.0.0 
* [BREAKING] Changed package basicly.
## 1.0.7 - Update shamsi_date version.
## 1.0.6 - Remove flushbar package.
## 1.0.5 - Fix Time Picker Bugs.
## 1.0.4 - Fix Bugs.
## 1.0.3 - Fix disabled dates in release mode.
## 1.0.2 - Add min and max date.
## 1.0.1 - Add theme color ,fix bugs.
## 1.0.0 - Add year picker and month picker, add disable feature,fix bugs.
## 0.0.1 - TODO: Add release date.
* TODO: Describe initial release.
